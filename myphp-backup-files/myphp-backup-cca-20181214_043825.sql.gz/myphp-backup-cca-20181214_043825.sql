CREATE DATABASE IF NOT EXISTS `cca`;

USE `cca`;

SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `carruselinicio`;

CREATE TABLE `carruselinicio` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `urlInicio` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8;

INSERT INTO `carruselinicio` VALUES ("35","imagenes/chedraui.jpg"),
("39","imagenes/coppel.png");


DROP TABLE IF EXISTS `carruselnoticias`;

CREATE TABLE `carruselnoticias` (
  `id_cn` int(15) NOT NULL AUTO_INCREMENT,
  `urlimagen` varchar(50) NOT NULL,
  `noticias` varchar(50) NOT NULL,
  PRIMARY KEY (`id_cn`),
  KEY `noticias` (`noticias`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

INSERT INTO `carruselnoticias` VALUES ("20","imagenesCarruselNoticias/chedraui.jpg","java ya no sera gratuito"),
("21","imagenesCarruselNoticias/coppel.png","Tony Stark murio ayer"),
("22","imagenesCarruselNoticias/chedraui.jpg","java ya no sera gratuito");


DROP TABLE IF EXISTS `contacto`;

CREATE TABLE `contacto` (
  `id_contacto` int(50) NOT NULL AUTO_INCREMENT,
  `urlimagen` varchar(250) NOT NULL,
  `nombrec` varchar(250) NOT NULL,
  `direccionc` varchar(250) NOT NULL,
  `telefonoc` varchar(15) NOT NULL,
  `horarioc` varchar(12) NOT NULL,
  `pgfbc` varchar(250) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  PRIMARY KEY (`id_contacto`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

INSERT INTO `contacto` VALUES ("18","imagencca/coppel.png","Camara","sss","sss","sss","sss","camara");


DROP TABLE IF EXISTS `cursos`;

CREATE TABLE `cursos` (
  `id_cursos` int(15) NOT NULL AUTO_INCREMENT,
  `dia` varchar(5) DEFAULT NULL,
  `mes` varchar(10) DEFAULT NULL,
  `nombre` varchar(300) DEFAULT NULL,
  `sede` varchar(250) DEFAULT NULL,
  `horario` varchar(11) DEFAULT NULL,
  `precio` varchar(15) DEFAULT NULL,
  `descripcion` varchar(350) DEFAULT NULL,
  `cupo` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id_cursos`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO `cursos` VALUES ("5","30","OCT","PHP Desde cero","CCA","08:00-20:00","$623","Curso de PHP para pricipiantes","6"),
("6","12","MAR","PYTHON encode","Acayucan","08:00-18:30","gratuito","nuevas actualizaciones","12");


DROP TABLE IF EXISTS `descuentos`;

CREATE TABLE `descuentos` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `direccion` varchar(250) NOT NULL,
  `telefono` varchar(15) NOT NULL,
  `horario` varchar(12) NOT NULL,
  `pgfb` varchar(200) NOT NULL,
  `urlimagen` varchar(100) NOT NULL,
  `urlimagenpromo` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO `descuentos` VALUES ("6","gfh","fgh","fgh","fgh","fgh","imagenes/coppel.png","imagenespromo/coppel.png");


DROP TABLE IF EXISTS `empresas`;

CREATE TABLE `empresas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tipo` varchar(50) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `direccion` varchar(250) NOT NULL,
  `telefono` varchar(15) NOT NULL,
  `horario` varchar(12) NOT NULL,
  `pgfb` varchar(200) NOT NULL,
  `urlimagen` varchar(150) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;

INSERT INTO `empresas` VALUES ("20","Boutiques","Chedraui","Enriquez","9241638234","08:00-20:00","fb","imagenes/coppel.png"),
("22","Electronica","coppel","calle PorfirioDiaz","9246234","08:00-20:00","coppel.fb","imagenes/coppel.png"),
("23","Farmacias","Chedraui","centro","9241638234","08:00-18:30","dfgdf","imagenes/coppel.png"),
("24","Tortillerias","maseca","calle PorfirioDiaz","9246234","08:00-20:00","maseca.fb","imagenes/coppel.png");


DROP TABLE IF EXISTS `galeria`;

CREATE TABLE `galeria` (
  `id_galeria` int(50) NOT NULL AUTO_INCREMENT,
  `mes` varchar(15) NOT NULL,
  `rutaimg` varchar(250) NOT NULL,
  PRIMARY KEY (`id_galeria`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

INSERT INTO `galeria` VALUES ("8","Enero","image/chedraui.jpg"),
("13","Febrero","image/coppel.png");


DROP TABLE IF EXISTS `meses`;

CREATE TABLE `meses` (
  `id_mes` int(50) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(10) NOT NULL,
  `urlimagen` varchar(100) NOT NULL,
  PRIMARY KEY (`id_mes`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

INSERT INTO `meses` VALUES ("6","Enero","imagenes/chedraui.jpg"),
("9","Febrero","imagenes/coppel.png");


DROP TABLE IF EXISTS `noticias`;

CREATE TABLE `noticias` (
  `id_noticias` int(15) NOT NULL AUTO_INCREMENT,
  `encabezado` varchar(150) DEFAULT NULL,
  `urlimagen` varchar(50) DEFAULT NULL,
  `descripcion` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id_noticias`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `noticias` VALUES ("1","java ya no sera gratuito","imagenesNoticias/j.jpg","La empresa encargada de dar soporte a java ha declarado que ya no lo dara, por ciertas cuestiones quien desee soiporte debera pagar cuota para obtenerlo."),
("4","Tony Stark murio ayer","imagenesNoticias/coppel.png","a falta de oxigeno, comida y agua, el multimillonario, genio, playboy filantropo y superheroe murio.");


DROP TABLE IF EXISTS `personas`;

CREATE TABLE `personas` (
  `id_personas` int(15) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(250) NOT NULL,
  `apellido` varchar(250) NOT NULL,
  `empresa` varchar(300) NOT NULL,
  `correo` varchar(100) NOT NULL,
  `curso` varchar(300) NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_personas`),
  KEY `curso` (`curso`),
  CONSTRAINT `personas_ibfk_1` FOREIGN KEY (`curso`) REFERENCES `cursos` (`nombre`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

INSERT INTO `personas` VALUES ("7","Francisco","Morales","Google","","PHP Desde cero","2018-12-12 12:02:18"),
("8","Francisco","Morales","dim","","PHP Desde cero","2018-12-12 12:02:18"),
("9","Luis","marcos","divin","","PYTHON encode","2018-12-12 12:02:18"),
("10","Matilde","Hlz","ojkh","","PHP Desde cero","2018-12-12 12:02:59"),
("11","asd","sdsd","sdfsdf","sasasd@sfd","PYTHON encode","2018-12-12 21:50:27");


DROP TABLE IF EXISTS `usuarioadmin`;

CREATE TABLE `usuarioadmin` (
  `id` int(10) NOT NULL,
  `usuario` varchar(50) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  `nivel` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `usuarioadmin` VALUES ("0","admin","12312312","1");


SET foreign_key_checks = 1;
